package ca.uhn.fhir.jpa.starter.custom;

import java.util.List;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Parameters;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.StructureMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.rest.annotation.Operation;
import ca.uhn.fhir.rest.annotation.OperationParam;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import ca.uhn.fhir.rest.param.UriParam;
import ca.uhn.fhir.rest.server.IResourceProvider;

@Component
public class CustomTransformProvider implements IResourceProvider{

    @Autowired
    private IFhirResourceDao<StructureMap> structureMapDao;

    private FhirContext fhirContext;

    public CustomTransformProvider(){
        this.fhirContext = FhirContext.forR4();
        System.out.println("StructureMap constructor .......");
    }

    @Override
    public Class<StructureMap> getResourceType() {
        return StructureMap.class;
    }

    @Operation(name = "$transform", idempotent = true)
    public Parameters transform(
        @OperationParam(name = "source", min=1, max=1) StringType source,
        @OperationParam(name = "content", min=1, max=1) IBaseResource content,
        RequestDetails requestDetails) {

            // Search for the patient
            SearchParameterMap structureMapParams = new SearchParameterMap();
            structureMapParams.add(StructureMap.SP_URL, new UriParam(source.toString()));

            List<StructureMap> structureMapResults = 
                structureMapDao.searchForResources(structureMapParams, requestDetails);
            if(structureMapResults.isEmpty())
                throw new IllegalArgumentException("StructureMap not found " + source);
            
            StructureMap thStructureMap = structureMapResults.get(0);
            Parameters output =  new Parameters();

            output.addParameter().setName("return").setResource((Resource)content);
            return output;
    }
}

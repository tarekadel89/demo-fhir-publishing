package ca.uhn.fhir.jpa.starter.custom;

import ca.uhn.fhir.interceptor.api.Hook;
import ca.uhn.fhir.interceptor.api.Interceptor;
import ca.uhn.fhir.interceptor.api.Pointcut;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDaoPatient;
import ca.uhn.fhir.jpa.api.dao.IFhirSystemDao;
import ca.uhn.fhir.rest.api.server.RequestDetails;
import oracle.sql.DATE;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.r4.model.Bundle.BundleEntryRequestComponent;
import org.hl7.fhir.r4.model.CarePlan;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Composition;
import org.hl7.fhir.r4.model.DateTimeType;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.Device.DeviceDeviceNameComponent;
import org.hl7.fhir.r4.model.Device.DeviceNameType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.ListResource;
import org.hl7.fhir.r4.model.ListResource.ListEntryComponent;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Narrative;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Provenance;
import org.hl7.fhir.r4.model.Provenance.ProvenanceEntityComponent;
import org.hl7.fhir.r4.model.Provenance.ProvenanceEntityRole;
import org.hl7.fhir.r4.model.Reference;
import org.springframework.beans.factory.annotation.Autowired;

@Interceptor
public class CustomTransactionBundleInterceptor {

    private static final String MHR_CONTENT_TYPES_SYSTEM = "https://healthterminologies.gov.au/fhir/CodeSystem/mhr-content-types-1";
    private static final String OBESITY_CARE_PLAN_CODE = "obesity_care_plan";

    @Autowired
    private IFhirSystemDao<Bundle, Meta> systemDao;

    @Autowired
    private IFhirResourceDaoPatient<Patient> patientDao;

    public CustomTransactionBundleInterceptor(){
        System.out.println("Interceptor instantiated");
    }
    
    @Hook(Pointcut.SERVER_PROCESSING_COMPLETED_NORMALLY)
    public void afterTransactionCompleted(RequestDetails theRequestDetails) {
        // Check if the request was a transaction Bundle
        if (theRequestDetails.getResource() instanceof Bundle) {
            Bundle theBundle = (Bundle) theRequestDetails.getResource();
            if(!theBundle.getType().equals(Bundle.BundleType.TRANSACTION)){
                System.out.println("Not a transaction Bundle");
                return;
            }

            for (Bundle.BundleEntryComponent entry : theBundle.getEntry()) {
                if (entry.getResource() instanceof ListResource) {
                    ListResource theList = (ListResource)entry.getResource().copy();
                    if(theList.getCode().getCodingFirstRep().getSystem().equals(MHR_CONTENT_TYPES_SYSTEM)
                        && theList.getCode().getCodingFirstRep().getCode().equals(OBESITY_CARE_PLAN_CODE)
                    ){
                        createCarePlanDocument(theBundle, theRequestDetails);
                    }
                }
            }

        }
    }

     private void createCarePlanDocument(Bundle carePlanBundle, RequestDetails thRequestDetails) {

        ListResource docList = new ListResource();

        CarePlan theCarePlan = new CarePlan();

        // Bundle
        Bundle docBundle = new Bundle();
        // bundle type = document
        docBundle.setType(Bundle.BundleType.DOCUMENT);

        // Composition
        Composition docComposition = new Composition();

        String docCompositionId = UUID.randomUUID().toString();
        docComposition.setId(docCompositionId);

        docComposition.setStatus(Composition.CompositionStatus.FINAL);
        docComposition.setType(
                new CodeableConcept().addCoding(new Coding(MHR_CONTENT_TYPES_SYSTEM, OBESITY_CARE_PLAN_CODE, "Obesity Care Plan")));
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy hh:mm a z");

        // Add Plan of Care Section to the Composition
        Composition.SectionComponent sectionPlanOfCare = new Composition.SectionComponent();
        sectionPlanOfCare.setTitle("Plan of Care");
        sectionPlanOfCare.setCode(new CodeableConcept().addCoding(new Coding("http://loinc.org", "18776-5",
                "Plan of care note")));
        Narrative planOfCareNarrative = new Narrative();
        planOfCareNarrative.setStatus(Narrative.NarrativeStatus.GENERATED);
        
        // add subject, author and custodian
        String docSubjectId = UUID.randomUUID().toString();
        
        docComposition.setSubject(new Reference("urn:uuid:" + docSubjectId));

        // author
        Device docAuthor = new Device();
        // id
        String docAuthorId = UUID.randomUUID().toString();
        docAuthor.setId(docAuthorId);
        // identifier
        docAuthor.addIdentifier(new Identifier().setSystem("http://ns.electronichealth.net.au/id/pcehr/paid/1.0")
                .setValue("8003640003000026"));
        // name
        docAuthor.addDeviceName(
                new DeviceDeviceNameComponent().setName("My Health Record").setType(DeviceNameType.MANUFACTURERNAME));
        // add the device as an author
        docComposition.addAuthor(new Reference("urn:uuid:" + docAuthorId).setDisplay("My Health Record"));
        
        // custodian
        Organization docCustodian = new Organization();
        // id
        String docCustodianId = UUID.randomUUID().toString();
        docCustodian.setId(docCustodianId);
        // identifier
        docCustodian.addIdentifier(new Identifier().setSystem("http://hl7.org.au/id/abn").setValue("84425496912"));
        // name
        docCustodian.setName("My Health Record system operator");
        // reference the custodian in the composition
        docComposition.setCustodian(new Reference("urn:uuid:" + docCustodianId)); // Example custodian reference
        
        // Provenance
        Provenance docProvenance = new Provenance();
        Provenance.ProvenanceAgentComponent authorAgent = new Provenance.ProvenanceAgentComponent();
        authorAgent.setType(new CodeableConcept().addCoding(
                new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                        "author", "Author")));
        
        authorAgent.setWho(new Reference().setDisplay("My Health Record"));
        docProvenance.addAgent(authorAgent);

        Provenance.ProvenanceAgentComponent custodianAgent = new Provenance.ProvenanceAgentComponent();
                    custodianAgent.setType(new CodeableConcept()
                            .addCoding(new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                                    "custodian", "Custodian")));
        
        custodianAgent.setWho(new Reference().setDisplay("My Health Record system operator"));
        docProvenance.addAgent(custodianAgent);

        for (Bundle.BundleEntryComponent entry : carePlanBundle.getEntry()) {
            switch (entry.getResource().getResourceType()) {
                case List:
                    ListResource theList = (ListResource)entry.getResource();
                    docList.addIdentifier(theList.getIdentifierFirstRep());
                    docList.setStatus(ListResource.ListStatus.CURRENT);
                    docList.setMode(ListResource.ListMode.SNAPSHOT);
                    docList.setDate(theList.getDate());
                    docList.setTitle(
                        "Obesity CarePlan Document from a Care Plan submitted on " + formatter.format(docList.getDate()));
                    docList.setCode(
                        new CodeableConcept().addCoding(new Coding(MHR_CONTENT_TYPES_SYSTEM, OBESITY_CARE_PLAN_CODE, "Obesity Care Plan")));
                    docList.setSubject(theList.getSubject());
                    docList.setSource(theList.getSource());
                                
                    docBundle.setIdentifier(docList.getIdentifierFirstRep());
                    docBundle.setTimestamp(docList.getDate());
                    
                    docProvenance.setOccurred(new DateTimeType(docList.getDate()));
                    docProvenance.setRecorded(docList.getDate());
                    docProvenance.addEntity(new ProvenanceEntityComponent().
                        setRole(ProvenanceEntityRole.SOURCE).
                        setWhat(new Reference(theList.getIdElement())));
                    
                    docComposition.setDate(docList.getDate());
                    docComposition.setTitle(
                        "Obesity CarePlan Document from a Care Plan submitted on " + formatter.format(docList.getDate()));

                    Patient docSubject = patientDao.read(docList.getSubject().getReferenceElement(), thRequestDetails);
                    docSubject.setId(docSubjectId);

                    // Add the Composition to the Bundle
                    docBundle.addEntry().setResource(docComposition).setFullUrl("urn:uuid:" + docCompositionId);
                    // add to the patient subject document Bundle
                    docBundle.addEntry().setResource(docSubject).setFullUrl("urn:uuid:" + docSubjectId);
                    // add to the device author document Bundle
                    docBundle.addEntry().setResource(docAuthor).setFullUrl("urn:uuid:" + docSubjectId);
                    // add to the organization custodian document Bundle
                    docBundle.addEntry().setResource(docCustodian).setFullUrl("urn:uuid:" + docCustodianId);

                    break;
                case CarePlan:
                    theCarePlan = (CarePlan)entry.getResource().copy();
                    planOfCareNarrative.setDivAsString(theCarePlan.getText().getDivAsString());
                    sectionPlanOfCare.setText(planOfCareNarrative);
                    docComposition.addSection(sectionPlanOfCare);
                    break;
                default:
                    break;
            }
            
        }
        



        // Create a transaction Bundle
        Bundle transactionBundle = new Bundle();
        transactionBundle.setType(Bundle.BundleType.TRANSACTION);
        transactionBundle.setId(UUID.randomUUID().toString());
        transactionBundle.setTimestamp(new Date());

    
        // Step 1: Prepare the Document Bundle entry (POST)
        BundleEntryRequestComponent bundleEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("Bundle");
        BundleEntryComponent bundleEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(docBundle)
            .setRequest(bundleEntryRequest);
    
        // Step 2: Prepare the Provenance entry (POST)
        BundleEntryRequestComponent provenanceEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("Provenance");
        BundleEntryComponent provenanceEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(docProvenance)
            .setRequest(provenanceEntryRequest);
    
        // Step 3: Prepare the List resource (POST) with references to the previous entries
        docList.addEntry(new ListEntryComponent().setItem(new Reference(bundleEntry.getFullUrl())));
        docList.addEntry(new ListEntryComponent().setItem(new Reference(provenanceEntry.getFullUrl())));
    
        BundleEntryRequestComponent listEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("List");
        BundleEntryComponent listEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(docList)
            .setRequest(listEntryRequest);
    
        // Step 4: Update the Provenance with the List as a target
        docProvenance.addTarget(new Reference(listEntry.getFullUrl()));
    
        // Add entries to transaction bundle
        transactionBundle.addEntry(bundleEntry);
        transactionBundle.addEntry(provenanceEntry);
        transactionBundle.addEntry(listEntry);

        systemDao.transaction(thRequestDetails, transactionBundle);
        System.out.println("************************************************* finished adding the document of a CarePlan *****************************************");
    }
}

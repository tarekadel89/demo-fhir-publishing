package ca.uhn.fhir.jpa.starter.custom;

import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.jpa.searchparam.SearchParameterMap;
import ca.uhn.fhir.narrative.DefaultThymeleafNarrativeGenerator;
import ca.uhn.fhir.rest.annotation.OptionalParam;
import ca.uhn.fhir.rest.annotation.RequiredParam;
import ca.uhn.fhir.rest.param.DateParam;
import ca.uhn.fhir.rest.param.DateRangeParam;
import ca.uhn.fhir.rest.param.ReferenceParam;
import ca.uhn.fhir.rest.param.StringParam;
import ca.uhn.fhir.rest.param.TokenParam;
//import ca.uhn.fhir.rest.param.UriParam;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.util.FhirTerser;

import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.instance.model.api.IIdType;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.r4.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.r4.model.Bundle.BundleEntryRequestComponent;
import org.hl7.fhir.r4.model.Device.DeviceNameType;
import org.hl7.fhir.r4.model.ListResource.ListEntryComponent;
import org.hl7.fhir.r4.model.Provenance.ProvenanceEntityComponent;
import org.hl7.fhir.r4.model.Provenance.ProvenanceEntityRole;
import org.hl7.fhir.r5.model.IdType;
import org.hl7.fhir.r4.model.Device.DeviceDeviceNameComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import ca.uhn.fhir.context.FhirContext;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDao;
import ca.uhn.fhir.jpa.api.dao.IFhirResourceDaoPatient;
import ca.uhn.fhir.jpa.api.dao.IFhirSystemDao;
import ca.uhn.fhir.rest.api.SortOrderEnum;
import ca.uhn.fhir.rest.api.SortSpec;
import ca.uhn.fhir.rest.api.server.IBundleProvider;
import ca.uhn.fhir.rest.api.server.RequestDetails;

import java.util.List;
import java.util.Map;
//import java.util.Optional;
import java.util.UUID;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.text.SimpleDateFormat;
//import java.time.LocalDateTime;
//import java.time.format.DateTimeFormatter;

@Component
public class CustomListProvider implements IResourceProvider {

    @Autowired
    private IFhirSystemDao<Bundle, Meta> systemDao;

    @Autowired
    private IFhirResourceDao<ListResource> listDao;

    @Autowired
    private IFhirResourceDao<DiagnosticReport> diagnosticReportDao;

    @Autowired
    private IFhirResourceDao<Bundle> bundleDao;

    @Autowired
    private IFhirResourceDaoPatient<Patient> patientDao;

    @Autowired
    private IFhirResourceDao<Practitioner> practitionerDao;

    @Autowired
    private IFhirResourceDao<PractitionerRole> practitionerRoleDao;

    @Autowired
    private IFhirResourceDao<Device> deviceDao;

    @Autowired
    private IFhirResourceDao<Organization> organizationDao;

    @Autowired
    private IFhirResourceDao<RelatedPerson> relatedPersonDao;

    @Autowired
    private IFhirResourceDao<QuestionnaireResponse> questionnaireResponseDao;

    @Autowired
    private IFhirResourceDao<Questionnaire> questionnaireDao;

    @Autowired
    private IFhirResourceDao<Provenance> provenanceDao;

    @Autowired
    private CustomIpsGenerator ipsGenerator;

    private FhirContext ctx;

    // Constants
    private static final String SHIP_CONCEPTS_CODE_SYSTEM = "http://example.org/CodeSystem/ship-concepts";
    private static final Coding QUERY_RESULT_CODE = new Coding(SHIP_CONCEPTS_CODE_SYSTEM, "query-result",
            "Query result");
    private static final Coding SHIP_ORIGIN_STATIC = new Coding(SHIP_CONCEPTS_CODE_SYSTEM, "static", "Static");
    private static final Coding SHIP_ORIGIN_ON_DEMAND = new Coding(SHIP_CONCEPTS_CODE_SYSTEM, "on-demand", "On demand");

    private static final String PATIENT_CULTURAL_BACKGROUND_URL = "http://hl7.org.au/fhir/StructureDefinition/patient-cultural-background";
    private static final String COMMUNITY_AFFILIATION_URL = "http://hl7.org.au/fhir/StructureDefinition/community-affiliation";
    
    private static final String MHR_CONTENT_TYPES_SYSTEM = "https://healthterminologies.gov.au/fhir/CodeSystem/mhr-content-types-1";
    private static final String PATIENT_STORY_QR = "patient_story_questionnaire_response";
    private static final String LOINC_SYSTEM = "http://loinc.org";
    private static final String PATIENT_SUMMARY_LOINC = "60591-5";

    public CustomListProvider() {
        ctx = FhirContext.forR4();
        System.out.println("Custom List Provider Initializing");
        
    }

    @Override
    public Class<ListResource> getResourceType() {
        return ListResource.class;
    }

    @Search(queryName = "questionnaireResponsesByPatient")
    public List<IBaseResource> questionnaireResponsesByPatient(
        @RequiredParam(name = "patient.identifier") TokenParam patientIdentifier,
        @RequiredParam(name = "patient.birthdate") DateParam patientBirthdate,
        @RequiredParam(name = "patient.family") StringParam patientFamily,
        @RequiredParam(name = "patient.gender") TokenParam patientGender, RequestDetails requestDetails) {
        // Named query results holder
        List<IBaseResource> retVal = new ArrayList<>();

        // Search for the patient
        List<Patient> patientResources = searchPatient(patientIdentifier, patientBirthdate, patientFamily,
                patientGender, requestDetails);

        if (patientResources.isEmpty()) {
            // Handle case where no patient is found
            return retVal;
        } else if (patientResources.size() > 1) {
            // Create an operation outcome with error for multiple patients
            retVal.add(generateOperationOutcome(OperationOutcome.IssueSeverity.ERROR,
                    OperationOutcome.IssueType.PROCESSING, "Multiple patients found with the given criteria."));
            return retVal;
        }

        Patient currPatient = patientResources.get(0); // Current patient is the first matching patient. This is working

        SearchParameterMap qrParams = new SearchParameterMap();
        qrParams.add("patient", new ReferenceParam("Patient/" + currPatient.getIdPart()));
        qrParams.setSort(new SortSpec("date", SortOrderEnum.DESC));
        List<ListResource> listResources = listDao.searchForResources(qrParams, requestDetails);

        for (ListResource list : listResources) {
            boolean hasQuestionnaireResponse = false;
            boolean hasProvenance = false;
            QuestionnaireResponse qrResource = null;
            Provenance provResource = null;
            Organization custodianOrg = null;

            // Loop through entries to check references without assuming sequence order
            for (ListResource.ListEntryComponent entry : list.getEntry()) {
                if (entry.hasItem() && entry.getItem().hasReference()) {
                    String ref = entry.getItem().getReference();

                    // Check if reference is to a QuestionnaireResponse
                    if (ref.startsWith("QuestionnaireResponse/")) {
                        hasQuestionnaireResponse = true;
                        qrResource = questionnaireResponseDao.read(new IdType(ref), requestDetails);
                    }

                    // Check if reference is to a Provenance
                    if (ref.startsWith("Provenance/")) {
                        hasProvenance = true;
                        provResource = provenanceDao.read(new IdType(ref), requestDetails);
                        if (provResource != null) {
                            for (Provenance.ProvenanceAgentComponent agent : provResource.getAgent()) {
                                if (agent.hasType() && agent.getType().hasCoding()) {
                                    for (Coding coding : agent.getType().getCoding()) {
                                        if ("custodian".equals(coding.getCode())) {
                                            // Resolve the who reference (Organization)
                                            if (agent.getWho() != null && agent.getWho().getReference() != null) {
                                                String whoRef = agent.getWho().getReference();
                                                if (whoRef.startsWith("Organization/")) {
                                                    custodianOrg = organizationDao.read(new IdType(whoRef),
                                                            requestDetails);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Add to return list if both references are found
            if (hasQuestionnaireResponse && hasProvenance) {
                retVal.add(list);
                if (qrResource != null) {
                    retVal.add(qrResource);
                }
                if (provResource != null) {
                    retVal.add(provResource);
                }
                if (custodianOrg != null){
                    retVal.add(custodianOrg);
                }
            }
        }

        return retVal;
    }

    @Search(queryName = "documentsByPatient")
    public List<IBaseResource> documentsByPatient(
            @RequiredParam(name = "patient.identifier") TokenParam patientIdentifier,
            @RequiredParam(name = "patient.birthdate") DateParam patientBirthdate,
            @RequiredParam(name = "patient.family") StringParam patientFamily,
            @RequiredParam(name = "patient.gender") TokenParam patientGender, RequestDetails requestDetails) {
        // Named query results holder
        List<IBaseResource> retVal = new ArrayList<>();

        // Search for the patient
        List<Patient> patientResources = searchPatient(patientIdentifier, patientBirthdate, patientFamily,
                patientGender, requestDetails);

        if (patientResources.isEmpty()) {
            // Handle case where no patient is found
            return retVal;
        } else if (patientResources.size() > 1) {
            // Create an operation outcome with error for multiple patients
            retVal.add(generateOperationOutcome(OperationOutcome.IssueSeverity.ERROR,
                    OperationOutcome.IssueType.PROCESSING, "Multiple patients found with the given criteria."));
            return retVal;
        }

        Patient currPatient = patientResources.get(0);

        
        // check if there is a need to generate a patient authored IPS from Patient Story QR
        boolean generateMHRIPSFromPatientStory;
        // Fetch the patient's Lists of type "Patient Story"
        SearchParameterMap listPsQrMap = new SearchParameterMap()
            .add("patient", new ReferenceParam(currPatient.getIdElement().getValue()))
            .add("code", new TokenParam(MHR_CONTENT_TYPES_SYSTEM, PATIENT_STORY_QR));

        List<ListResource> patientStoryLists = listDao.searchForResources(listPsQrMap, requestDetails);

        // Fetch the patient's Lists of type "Patient Summary"
        SearchParameterMap listPsDocMap = new SearchParameterMap()
            .add("patient", new ReferenceParam(currPatient.getIdElement().getValue()))
            .add("code", new TokenParam(LOINC_SYSTEM, PATIENT_SUMMARY_LOINC));

        List<ListResource> psDocLists = listDao.searchForResources(listPsDocMap, requestDetails);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        for(ListResource patientStoryList : patientStoryLists){
            generateMHRIPSFromPatientStory = true;
            Provenance patientStoryProvenance = getProvenance(patientStoryList, requestDetails);
            for(ListResource psDocList: psDocLists){
                Provenance patientSummaryProvenance = getProvenance(psDocList, requestDetails);
                String formatted1 = sdf.format(patientStoryList.getDate());
                String formatted2 = sdf.format(psDocList.getDate());

                if (patientStoryProvenance.getEntityFirstRep().getWhat().getReference().equals(patientSummaryProvenance.getEntityFirstRep().getWhat().getReference())
                    && formatted1.equals(formatted2)
                ){
                    generateMHRIPSFromPatientStory = false;
                    break; // Exit the inner loop
                }
            }

             if(generateMHRIPSFromPatientStory){
                QuestionnaireResponse qr = questionnaireResponseDao.read(patientStoryList.getEntryFirstRep().getItem().getReferenceElement(), requestDetails);//fetchQuestionnaireResponse(patientStoryList.getEntryFirstRep().getItem(), requestDetails);
                generatePatientAuthoredIpsFromPatientStory(currPatient, "List/"+patientStoryList.getIdPart(), qr, requestDetails);
            }
        }
        
        // 2. generate MHR IPS
        generateMHRIPS(requestDetails, currPatient.getIdElement(), retVal);

        // 3.get native documents

        SearchParameterMap searchParamNativeDocs = new SearchParameterMap()
        .add("patient", new ReferenceParam(currPatient.getIdElement().getValue()));
        //.add("code", new TokenParam(LOINC_SYSTEM, PATIENT_SUMMARY_LOINC).setModifier(TokenParamModifier.NOT));

        List<ListResource> listNativeDocs = listDao.searchForResources(searchParamNativeDocs, requestDetails);

        for (ListResource list : listNativeDocs) {
            boolean hasDocumentBundle = false;
            boolean hasProvenance = false;
            Bundle documentBundle = null;
            Provenance documentProvenance = null;

            // Loop through entries to check references without assuming sequence order
            for (ListResource.ListEntryComponent entry : list.getEntry()) {
                if (entry.hasItem() && entry.getItem().hasReference()) {
                    String ref = entry.getItem().getReference();

                    // Check if reference is to a QuestionnaireResponse
                    if (ref.startsWith("Bundle/")) {
                        documentBundle = bundleDao.read(new IdType(ref), requestDetails);
                        if(documentBundle.getEntryFirstRep().getResource() instanceof Composition)
                            hasDocumentBundle = true;
                        else
                            documentBundle = null;
                    }

                    // Check if reference is to a Provenance
                    if (ref.startsWith("Provenance/")) {
                        hasProvenance = true;
                        documentProvenance = provenanceDao.read(new IdType(ref), requestDetails);
                    }
                }
            }

            // Add to return list if both references are found
            if (hasDocumentBundle && hasProvenance) {
                retVal.add(list);
                if (documentBundle != null) {
                    retVal.add(documentBundle);
                }
                if (documentProvenance != null) {
                    retVal.add(documentProvenance);
                }
            }
        }
        return retVal;
    }


    @Search(queryName = "discoverContentByPatient")
    public List<IBaseResource> discoverContentByPatient(
            @RequiredParam(name = "patient.identifier") TokenParam patientIdentifier,
            @RequiredParam(name = "patient.birthdate") DateParam patientBirthdate,
            @RequiredParam(name = "patient.family") StringParam patientFamily,
            @RequiredParam(name = "patient.gender") TokenParam patientGender, 
            @OptionalParam(name = ListResource.SP_IDENTIFIER) TokenParam listIdentifier,
            @OptionalParam(name = ListResource.SP_DATE) DateRangeParam listDate,
            @OptionalParam(name = ListResource.SP_CODE) TokenParam listCode,
            @OptionalParam(name = ListResource.SP_STATUS) TokenParam listStatus,
            RequestDetails requestDetails) {
        
        
        List<IBaseResource> retVal = new ArrayList<>();
       
        // Search for the patient
        List<Patient> patientResources = searchPatient(patientIdentifier, patientBirthdate, patientFamily,
                patientGender, requestDetails);

        if (patientResources.isEmpty()) {
            // Handle case where no patient is found
            return null;
        } else if (patientResources.size() > 1) {
            // Create an operation outcome with error for multiple patients
            OperationOutcome operationOutcome = (generateOperationOutcome(OperationOutcome.IssueSeverity.ERROR,
                    OperationOutcome.IssueType.PROCESSING, "Multiple patients found with the given criteria."));           
            retVal.add(operationOutcome);
            return retVal;
        }

        Patient currPatient = patientResources.get(0);

        // Create a search parameter map
        SearchParameterMap params = new SearchParameterMap();
        params.add(ListResource.SP_PATIENT, new ReferenceParam(currPatient.getIdElement()));

        if (listIdentifier != null) {
            params.add(ListResource.SP_IDENTIFIER, listIdentifier);
        }
        if (listDate != null) {
            params.add(ListResource.SP_DATE, listDate);
        }
        if (listStatus != null) {
            params.add(ListResource.SP_STATUS, listStatus);
        }
        if (listCode != null) {
            params.add(ListResource.SP_CODE, listCode);
            if(listCode.getSystem().equals(LOINC_SYSTEM)
                && listCode.getValue().equals(PATIENT_SUMMARY_LOINC)
            ){
                generateMHRIPS(requestDetails, currPatient.getIdElement(), retVal);
            }
        }
        //params.addInclude(ListResource.INCLUDE_ITEM);

        IBundleProvider bundleProvider = listDao.search(params, requestDetails);
        
        for(IBaseResource resource: bundleProvider.getResources(0, bundleProvider.sizeOrThrowNpe())){
            retVal.add(resource);
        }

        // additional OBS logic to fetch data from HDR
        
        return retVal;
    }
    
    
    @Search(queryName = "mhrPatientSummary")
    public List<IBaseResource> mhrPatientSummary(
        @RequiredParam(name = "patient.identifier") TokenParam patientIdentifier,
        @RequiredParam(name = "patient.birthdate") DateParam patientBirthdate,
        @RequiredParam(name = "patient.family") StringParam patientFamily,
        @RequiredParam(name = "patient.gender") TokenParam patientGender, RequestDetails requestDetails) {
        // Named query results holder
        List<IBaseResource> retVal = new ArrayList<>();
        
        // Search for the patient
        List<Patient> patientResources = searchPatient(patientIdentifier, patientBirthdate, patientFamily,
                patientGender, requestDetails);

        if (patientResources.isEmpty()) {
            // Handle case where no patient is found
            return retVal;
        } else if (patientResources.size() > 1) {
            // Create an operation outcome with error for multiple patients
            retVal.add(generateOperationOutcome(OperationOutcome.IssueSeverity.ERROR,
                    OperationOutcome.IssueType.PROCESSING, "Multiple patients found with the given criteria."));
            return retVal;
        }

        Patient currPatient = patientResources.get(0);

        generateMHRIPS(requestDetails, currPatient.getIdElement(), retVal);

        return retVal;
    }
    
    /**
    * Helper function to get the Provenance resource for a given resource.
    */
    private Provenance getProvenance(IBaseResource resource, RequestDetails requestDetails) {
        SearchParameterMap provenanceMap = new SearchParameterMap()
            .add("target", new ReferenceParam(resource.getIdElement().getValue()));

        // assuming we wouldn't have multiple provenances with the same target
        return provenanceDao.searchForResources(provenanceMap, requestDetails).get(0);
    }
    
    /**
    * Function to generate a Patient Summary from Patient Story QR.
    */
    private void generatePatientAuthoredIpsFromPatientStory(Patient patient, String source, QuestionnaireResponse qr,
            RequestDetails requestDetails) {
        
        Bundle qrDocumentBundle = new Bundle();

        // bundle identifier = random UUID for now
        Identifier docIdentifier = new Identifier().setSystem("http://digitalhealth.gov.au/identifiers")
                .setValue(UUID.randomUUID().toString());
        qrDocumentBundle.setIdentifier(docIdentifier);
        // bundle type = document
        qrDocumentBundle.setType(Bundle.BundleType.DOCUMENT);
        // bundle timestamp = now
        qrDocumentBundle.setTimestamp(qr.getAuthored());

        // Add a Composition to the Bundle
        Composition qrComposition = new Composition();
        // composition id
        String qrCompositionId = UUID.randomUUID().toString();
        qrComposition.setId(qrCompositionId);
        // status = final
        qrComposition.setStatus(Composition.CompositionStatus.FINAL);
        // type is MCV
        qrComposition.setType(
                new CodeableConcept().addCoding(new Coding("http://loinc.org", "60591-5", "Patient summary Document")));
        // date
        qrComposition.setDate(qr.getAuthored());
        // title
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy hh:mm a z");
        qrComposition.setTitle(
                "Patient Authored IPS from a Patient Story submitted on " + formatter.format(qr.getAuthored()));
        // Add patient story to Composition
        Composition.SectionComponent patientStorySection = new Composition.SectionComponent();
        patientStorySection.setTitle("Patient Story");
        patientStorySection.setCode(new CodeableConcept().addCoding(new Coding("http://loinc.org", "81338-6",
                "Patient Goals, preferences, and priorities for care experience")));
        Narrative patientStorySectionNarrative = new Narrative();
        patientStorySectionNarrative.setStatus(Narrative.NarrativeStatus.GENERATED);
        patientStorySectionNarrative.setDivAsString(getValueString(qr, "my_story_item"));
        patientStorySection.setText(patientStorySectionNarrative);
        qrComposition.addSection(patientStorySection);

        // subject
        Patient qrSubject = new Patient();
        // copy the current patient details
        qrSubject = patient.copy();
        // id just update the id
        String qrSubjectId = UUID.randomUUID().toString();
        qrSubject.setId(qrSubjectId);
        // add a reference to the subject in the composition
        qrComposition.setSubject(new Reference("urn:uuid:" + qrSubjectId));
        // Add cultural background extension to Patient
        Extension culturalBackgroundExtension = new Extension(PATIENT_CULTURAL_BACKGROUND_URL);
        culturalBackgroundExtension.setValue(getValueCodeableConcept(qr, "my_culture_item"));
        qrSubject.addExtension(culturalBackgroundExtension);

        // Add community affiliation extension to Patient
        Extension communityAffiliationExtension = new Extension(COMMUNITY_AFFILIATION_URL);
        communityAffiliationExtension.setValue(new StringType(getValueString(qr, "my_place_item")));
        qrSubject.addExtension(communityAffiliationExtension);

        // author
        Device qrAuthor = new Device();
        // id
        String qrAuthorId = UUID.randomUUID().toString();
        qrAuthor.setId(qrAuthorId);
        // identifier
        qrAuthor.addIdentifier(new Identifier().setSystem("http://ns.electronichealth.net.au/id/pcehr/paid/1.0")
                .setValue("8003640003000026"));
        // name
        qrAuthor.addDeviceName(
                new DeviceDeviceNameComponent().setName("My Health Record").setType(DeviceNameType.MANUFACTURERNAME));
        // add the device as an author
        qrComposition.addAuthor(new Reference("urn:uuid:" + qrAuthorId).setDisplay("My Health Record"));

        // custodian
        Organization qrCustodian = new Organization();
        // id
        String qrCustodianId = UUID.randomUUID().toString();
        qrCustodian.setId(qrCustodianId);
        // identifier
        qrCustodian.addIdentifier(new Identifier().setSystem("http://hl7.org.au/id/abn").setValue("84425496912"));
        // name
        qrCustodian.setName("My Health Record system operator");
        // reference the custodian in the composition
        qrComposition.setCustodian(new Reference("urn:uuid:" + qrCustodianId)); // Example custodian reference

        // Add the Composition to the Bundle
        qrDocumentBundle.addEntry().setResource(qrComposition).setFullUrl("urn:uuid:" + qrCompositionId);
        // add to the patient subject document Bundle
        qrDocumentBundle.addEntry().setResource(qrSubject).setFullUrl("urn:uuid:" + qrSubjectId);
        // add to the device author document Bundle
        qrDocumentBundle.addEntry().setResource(qrAuthor).setFullUrl("urn:uuid:" + qrAuthorId);
        // add to the organization custodian document Bundle
        qrDocumentBundle.addEntry().setResource(qrCustodian).setFullUrl("urn:uuid:" + qrCustodianId);

        // Save the provenance
        Provenance qrProvenance = new Provenance();
        
        // set the occurrence as the QR authoring date and time
        qrProvenance.setOccurred(new DateTimeType(qr.getAuthored()));
        
        // set the recorded as the QR authoring date and time
        qrProvenance.setRecorded(qr.getAuthored());

        // Set the agent details for author
        Provenance.ProvenanceAgentComponent authorAgent = new Provenance.ProvenanceAgentComponent();
        authorAgent.setType(new CodeableConcept().addCoding(
                new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                        "author", "Author")));
        
        authorAgent.setWho(createResourceReference(qrAuthor, null, requestDetails));
        qrProvenance.addAgent(authorAgent);
        
        // set the agent details for custodian
        Provenance.ProvenanceAgentComponent custodianAgent = new Provenance.ProvenanceAgentComponent();
                    custodianAgent.setType(new CodeableConcept()
                            .addCoding(new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                                    "custodian", "Custodian")));
        
        custodianAgent.setWho(createResourceReference(qrCustodian, null, requestDetails));
        qrProvenance.addAgent(custodianAgent);

        // set the source entity
        qrProvenance.addEntity(new ProvenanceEntityComponent().
            setRole(ProvenanceEntityRole.SOURCE).
            setWhat(new Reference(source)));

        ListResource qrList = new ListResource();
        
        // add identifier
        qrList.addIdentifier(docIdentifier);
        // add status
        qrList.setStatus(ListResource.ListStatus.CURRENT);
        // Populate mode
        qrList.setMode(ListResource.ListMode.SNAPSHOT);
        // title
        qrList.setCode(
                new CodeableConcept().addCoding(new Coding("http://loinc.org", "60591-5", "Patient summary Document")));
        // date
        qrList.setDate(qr.getAuthored());
        // title
        qrList.setTitle(
                "Patient Authored IPS from a Patient Story submitted on " + formatter.format(qr.getAuthored()));
        
        qrList.setSubject(new Reference(patient.getIdElement().toUnqualifiedVersionless()));


        // Create a transaction Bundle
        Bundle transactionBundle = new Bundle();
        transactionBundle.setType(Bundle.BundleType.TRANSACTION);
        transactionBundle.setId(UUID.randomUUID().toString());
    
        // Step 1: Prepare the Document Bundle entry (POST)
        BundleEntryRequestComponent bundleEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("Bundle");
        BundleEntryComponent bundleEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(qrDocumentBundle)
            .setRequest(bundleEntryRequest);
    
        // Step 2: Prepare the Provenance entry (POST)
        BundleEntryRequestComponent provenanceEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("Provenance");
        BundleEntryComponent provenanceEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(qrProvenance)
            .setRequest(provenanceEntryRequest);
    
        // Step 3: Prepare the List resource (POST) with references to the previous entries
        qrList.addEntry(new ListEntryComponent().setItem(new Reference(bundleEntry.getFullUrl())));
        qrList.addEntry(new ListEntryComponent().setItem(new Reference(provenanceEntry.getFullUrl())));
    
        BundleEntryRequestComponent listEntryRequest = new BundleEntryRequestComponent().setMethod(Bundle.HTTPVerb.POST).setUrl("List");
        BundleEntryComponent listEntry = new Bundle.BundleEntryComponent()
            .setFullUrl("urn:uuid:" + UUID.randomUUID())  // Temporary UUID reference
            .setResource(qrList)
            .setRequest(listEntryRequest);
    
        // Step 4: Update the Provenance with the List as a target
        qrProvenance.addTarget(new Reference(listEntry.getFullUrl()));
    
        // Add entries to transaction bundle
        transactionBundle.addEntry(bundleEntry);
        transactionBundle.addEntry(provenanceEntry);
        transactionBundle.addEntry(listEntry);

        //bundleDao.create(transactionBundle, requestDetails);
        systemDao.transaction(requestDetails, transactionBundle);
    }

    private void generateMHRIPS(RequestDetails theRequestDetails, IIdType thePatientId, List<IBaseResource> retVal){
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMM-yyyy hh:mm a z");

        ListResource mhrIpsList = new ListResource();
        String mhrIpsListId = UUID.randomUUID().toString();
        mhrIpsList.setId(mhrIpsListId);

        Bundle mhrIpsBundle = (Bundle) ipsGenerator.generateIps(theRequestDetails, thePatientId, null);
        String mhrIpsBundleId = UUID.randomUUID().toString();
        mhrIpsBundle.setId(mhrIpsBundleId);

        Provenance mhrIpsProvenance = new Provenance();
        String mhrIpsProvenanceId = UUID.randomUUID().toString();
        mhrIpsProvenance.setId(mhrIpsProvenanceId);
        mhrIpsProvenance.addTarget(new Reference(mhrIpsListId));


        fixBundleReferences(mhrIpsBundle);

        // enhance the MHR generated IPS with the latest Patient Story QuestionnaireResponse
        QuestionnaireResponse latestPatientStoryQR = findPatientStoryQuestionnaireResponse(theRequestDetails, thePatientId);

        for(BundleEntryComponent bundleEntryComponent: mhrIpsBundle.getEntry()){
            switch (bundleEntryComponent.getResource().getResourceType()) {
                case Composition:
                    Composition composition = (Composition)bundleEntryComponent.getResource();
                    composition.setTitle("MHR Generated IPS on " + formatter.format(new Date()));
                    mhrIpsList.setTitle(composition.getTitle());
                    mhrIpsList.setDate(composition.getDate());
                    mhrIpsProvenance.setOccurred(new DateTimeType(composition.getDate()));
                    mhrIpsProvenance.setRecorded(composition.getDate());

                    if(latestPatientStoryQR != null){
                        Composition.SectionComponent patientStorySection = new Composition.SectionComponent();
                        patientStorySection.setTitle("Patient Story");
                        patientStorySection.setCode(new CodeableConcept().addCoding(new Coding("http://loinc.org", "81338-6",
                                "Patient Goals, preferences, and priorities for care experience")));
                        Narrative patientStorySectionNarrative = new Narrative();
                        patientStorySectionNarrative.setStatus(Narrative.NarrativeStatus.GENERATED);
                        patientStorySectionNarrative.setDivAsString(getValueString(latestPatientStoryQR, "my_story_item"));
                        patientStorySection.setText(patientStorySectionNarrative);
                        composition.addSection(patientStorySection);
                    }
                    break;
                case Patient:
                    Patient patient = (Patient)bundleEntryComponent.getResource();
                    if(latestPatientStoryQR != null){
                        // Add cultural background extension to Patient
                        Extension culturalBackgroundExtension = new Extension(PATIENT_CULTURAL_BACKGROUND_URL);
                        culturalBackgroundExtension.setValue(getValueCodeableConcept(latestPatientStoryQR, "my_culture_item"));
                        patient.addExtension(culturalBackgroundExtension);

                        // Add community affiliation extension to Patient
                        Extension communityAffiliationExtension = new Extension(COMMUNITY_AFFILIATION_URL);
                        communityAffiliationExtension.setValue(new StringType(getValueString(latestPatientStoryQR, "my_place_item")));
                        patient.addExtension(communityAffiliationExtension);
                    }
                    ctx.setNarrativeGenerator(new DefaultThymeleafNarrativeGenerator());
                    ctx.getNarrativeGenerator().populateResourceNarrative(ctx, patient);
                    break;
                default:
                    break;
            }
        }

         // author
         Device mhrIpsAuthor = new Device();
         // id
         String mhrIpsAuthorId = UUID.randomUUID().toString();
         mhrIpsAuthor.setId(mhrIpsAuthorId);
         // identifier
         mhrIpsAuthor.addIdentifier(new Identifier().setSystem("http://ns.electronichealth.net.au/id/pcehr/paid/1.0")
                 .setValue("8003640003000026"));
         // name
         mhrIpsAuthor.addDeviceName(
                 new DeviceDeviceNameComponent().setName("My Health Record").setType(DeviceNameType.MANUFACTURERNAME));
 
         // custodian
         Organization mhrIpsCustodian = new Organization();
         // id
         String mhrIpsCustodianId = UUID.randomUUID().toString();
         mhrIpsCustodian.setId(mhrIpsCustodianId);
         // identifier
         mhrIpsCustodian.addIdentifier(new Identifier().setSystem("http://hl7.org.au/id/abn").setValue("84425496912"));
         // name
         mhrIpsCustodian.setName("My Health Record system operator");

        // Set the agent details for author
        Provenance.ProvenanceAgentComponent authorAgent = new Provenance.ProvenanceAgentComponent();
        authorAgent.setType(new CodeableConcept().addCoding(
                new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                        "author", "Author")));
        
        authorAgent.setWho(createResourceReference(mhrIpsAuthor, null, theRequestDetails));
        mhrIpsProvenance.addAgent(authorAgent);
        
        // set the agent details for custodian
        Provenance.ProvenanceAgentComponent custodianAgent = new Provenance.ProvenanceAgentComponent();
                    custodianAgent.setType(new CodeableConcept()
                            .addCoding(new Coding("http://terminology.hl7.org/CodeSystem/provenance-participant-type",
                                    "custodian", "Custodian")));
        
        custodianAgent.setWho(createResourceReference(mhrIpsCustodian, null, theRequestDetails));
        mhrIpsProvenance.addAgent(custodianAgent);

        // set the source entity
        mhrIpsProvenance.addEntity(new ProvenanceEntityComponent().
            setRole(ProvenanceEntityRole.SOURCE).
            setWhat(new Reference("List/6")));
        
        // add identifier
        mhrIpsList.addIdentifier(mhrIpsBundle.getIdentifier());
        // add status
        mhrIpsList.setStatus(ListResource.ListStatus.CURRENT);
        // Populate mode
        mhrIpsList.setMode(ListResource.ListMode.SNAPSHOT);
        // title
        mhrIpsList.setCode(
                new CodeableConcept().addCoding(new Coding("http://loinc.org", "60591-5", "Patient summary Document")));

        mhrIpsList.setSubject(new Reference(thePatientId.toUnqualifiedVersionless()));

        //qrList.addEntry(new ListEntryComponent(new Reference(null)));
        ListEntryComponent bundleEntry = new ListEntryComponent(new Reference(mhrIpsBundle));
        ListEntryComponent provenanceEntry = new ListEntryComponent(new Reference(mhrIpsProvenance));

        mhrIpsList.addEntry(bundleEntry);
        mhrIpsList.addEntry(provenanceEntry);

        retVal.add(mhrIpsList);
        retVal.add(mhrIpsBundle);
        retVal.add(mhrIpsProvenance);
    }

    private void fixBundleReferences(Bundle bundle){

        //FhirContext ctx = FhirContext.forR4();

        Map<String, String> idToUuidMap = new HashMap<>();

        // Process each entry in the Bundle
        for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
            Resource resource = entry.getResource();
            String logicalId = resource.getIdElement().toUnqualifiedVersionless().getValue();
            String fullUrl = entry.getFullUrl();

            // Check if fullUrl is not already a UUID
            if (!fullUrl.startsWith("urn:uuid:")) {
                String uuid = "urn:uuid:" + UUID.randomUUID().toString();
                idToUuidMap.put(logicalId, uuid);
                entry.setFullUrl(uuid);
            } else {
                idToUuidMap.put(logicalId, fullUrl);
            }
        }

        // Replace references in the Bundle
        FhirTerser terser = ctx.newTerser();
        for (Bundle.BundleEntryComponent entry : bundle.getEntry()) {
            replaceReferences(entry.getResource(), idToUuidMap, terser);
        }
    }

    private static void replaceReferences(Resource resource, Map<String, String> idToUuidMap, FhirTerser terser) {
        // Use FhirTerser to navigate and update references
        terser.getAllPopulatedChildElementsOfType(resource, Reference.class).forEach(reference -> {
            String ref = reference.getReference();
            if (ref != null && ref.contains("/")) {
                if (idToUuidMap.containsKey(ref)) {
                    reference.setReference(idToUuidMap.get(ref));
                }
            }
        });

        // Handle nested sections in Composition
        if (resource instanceof Composition) {
            Composition composition = (Composition) resource;
            for (Composition.SectionComponent section : composition.getSection()) {
                for (Reference entryReference : section.getEntry()) {
                    String ref = entryReference.getReference();
                    if (ref != null && ref.contains("/") && !ref.startsWith("urn:uuid:")) {
                        // Extract the logical ID from the reference URL
                        String logicalId = ref;//.split("/")[1];
                        if (logicalId.contains("fhir/")) {
                            logicalId = logicalId.split("fhir/")[1];
                        } 
                        if (logicalId.contains("/_history")) {
                            logicalId = logicalId.split("/_history")[0];
                        }
                
                        // Check if the logical ID is in the map and update the reference
                        if (idToUuidMap.containsKey(logicalId)) {
                            entryReference.setReference(idToUuidMap.get(logicalId));
                        }
                    }
                }
            }
        }
    }

    private QuestionnaireResponse findPatientStoryQuestionnaireResponse(RequestDetails theRequestDetails, IIdType thePatientId){

        SearchParameterMap listPsQrMap = new SearchParameterMap()
            .add("patient", new ReferenceParam(thePatientId))
            .add("code", new TokenParam(MHR_CONTENT_TYPES_SYSTEM, PATIENT_STORY_QR));

        List<ListResource> patientStoryLists = listDao.searchForResources(listPsQrMap, theRequestDetails);
        if(patientStoryLists.isEmpty())
            return null;
        
        return questionnaireResponseDao.read(patientStoryLists.get(patientStoryLists.size()-1).getEntryFirstRep().getItem().getReferenceElement(), theRequestDetails);
    }

    // this function searches for a Patient using the identifier, birthday, family
    // name and gender
    private List<Patient> searchPatient(TokenParam patientIdentifier, DateParam patientBirthdate,
            StringParam patientFamily, TokenParam patientGender, RequestDetails requestDetails) {

        SearchParameterMap patientParams = new SearchParameterMap();
        patientParams.add("identifier", new TokenParam(patientIdentifier.getSystem(), patientIdentifier.getValue()));
        patientParams.add("birthdate", patientBirthdate);
        patientParams.add("family", patientFamily);
        patientParams.add("gender", patientGender);
        List<Patient> searchOutcome = patientDao.searchForResources(patientParams, requestDetails);

        return searchOutcome;
    }

    // this function returns an OperationOutcome based on given severity, issue type
    // and message
    private OperationOutcome generateOperationOutcome(OperationOutcome.IssueSeverity severity,
            OperationOutcome.IssueType issueType, String diagnostic) {
        OperationOutcome operationOutcome = new OperationOutcome();
        operationOutcome.addIssue().setSeverity(severity).setCode(issueType).setDiagnostics(diagnostic);

        return operationOutcome;
    }

    private Reference createResourceReference(Resource resource, IFhirResourceDao<?> resourceDao,
            RequestDetails requestDetails) {
        Reference resourceReference = new Reference();

        if (resource instanceof Patient) {
            Patient patient = (Patient) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(patient.getIdentifierFirstRep().getSystem(),
                    patient.getIdentifierFirstRep().getValue()));

            List<Patient> matchedPatients = patientDao.searchForResources(searchParams, requestDetails);

            if (!matchedPatients.isEmpty()) {
                Patient dbPatient = matchedPatients.get(0);
                resourceReference.setReference(dbPatient.getIdElement().getValue());
                resourceReference.setType("Patient");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(dbPatient.getIdentifierFirstRep().getSystem())
                                .setValue(dbPatient.getIdentifierFirstRep().getValue()));
                resourceReference.setDisplay(dbPatient.getNameFirstRep().getNameAsSingleString());
            } else {
                resourceReference.setType("Patient");
                resourceReference.setIdentifier(new Identifier().setSystem(patient.getIdentifierFirstRep().getSystem())
                        .setValue(patient.getIdentifierFirstRep().getValue()));
                if (patient.getNameFirstRep() != null)
                    resourceReference.setDisplay(patient.getNameFirstRep().getNameAsSingleString());
            }
        } else if (resource instanceof Practitioner) {
            Practitioner practitioner = (Practitioner) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(practitioner.getIdentifierFirstRep().getSystem(),
                    practitioner.getIdentifierFirstRep().getValue()));

            List<Practitioner> matchedPractitioners = practitionerDao.searchForResources(searchParams, requestDetails);

            if (!matchedPractitioners.isEmpty()) {
                Practitioner dbPractitioner = matchedPractitioners.get(0);
                resourceReference.setReference(dbPractitioner.getIdElement().getValue());
                resourceReference.setType("Practitioner");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(dbPractitioner.getIdentifierFirstRep().getSystem())
                                .setValue(dbPractitioner.getIdentifierFirstRep().getValue()));
                resourceReference.setDisplay(dbPractitioner.getNameFirstRep().getNameAsSingleString());
            } else {
                resourceReference.setType("Practitioner");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(practitioner.getIdentifierFirstRep().getSystem())
                                .setValue(practitioner.getIdentifierFirstRep().getValue()));
                if (practitioner.getNameFirstRep() != null)
                    resourceReference.setDisplay(practitioner.getNameFirstRep().getGivenAsSingleString());
            }
        } else if (resource instanceof PractitionerRole) {
            PractitionerRole practitionerRole = (PractitionerRole) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(practitionerRole.getIdentifierFirstRep().getSystem(),
                    practitionerRole.getIdentifierFirstRep().getValue()));

            List<PractitionerRole> matchedPractitionerRoles = practitionerRoleDao.searchForResources(searchParams,
                    requestDetails);

            if (!matchedPractitionerRoles.isEmpty()) {
                PractitionerRole dbPractitionerRole = matchedPractitionerRoles.get(0);
                resourceReference.setReference(dbPractitionerRole.getIdElement().getValue());
                resourceReference.setType("PractitionerRole");
                resourceReference.setIdentifier(
                        new Identifier().setSystem(dbPractitionerRole.getIdentifierFirstRep().getSystem())
                                .setValue(dbPractitionerRole.getIdentifierFirstRep().getValue()));
                // For display, might want to combine practitioner and organization names
                resourceReference.setDisplay("Practitioner Role");
            } else {
                resourceReference.setType("PractitionerRole");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(practitionerRole.getIdentifierFirstRep().getSystem())
                                .setValue(practitionerRole.getIdentifierFirstRep().getValue()));
            }
        } else if (resource instanceof RelatedPerson) {
            RelatedPerson relatedPerson = (RelatedPerson) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(relatedPerson.getIdentifierFirstRep().getSystem(),
                    relatedPerson.getIdentifierFirstRep().getValue()));

            List<RelatedPerson> matchedRelatedPersons = relatedPersonDao.searchForResources(searchParams,
                    requestDetails);

            if (!matchedRelatedPersons.isEmpty()) {
                RelatedPerson dbRelatedPerson = matchedRelatedPersons.get(0);
                resourceReference.setReference(dbRelatedPerson.getIdElement().getValue());
                resourceReference.setType("RelatedPerson");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(dbRelatedPerson.getIdentifierFirstRep().getSystem())
                                .setValue(dbRelatedPerson.getIdentifierFirstRep().getValue()));
                resourceReference.setDisplay(dbRelatedPerson.getNameFirstRep().getNameAsSingleString());
            } else {
                resourceReference.setType("RelatedPerson");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(relatedPerson.getIdentifierFirstRep().getSystem())
                                .setValue(relatedPerson.getIdentifierFirstRep().getValue()));
                if (relatedPerson.getNameFirstRep() != null)
                    resourceReference.setDisplay(relatedPerson.getNameFirstRep().getNameAsSingleString());
            }
        } else if (resource instanceof Device) {
            Device device = (Device) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(device.getIdentifierFirstRep().getSystem(),
                    device.getIdentifierFirstRep().getValue()));

            List<Device> matchedDevices = deviceDao.searchForResources(searchParams, requestDetails);

            if (!matchedDevices.isEmpty()) {
                Device dbDevice = matchedDevices.get(0);
                resourceReference.setReference(dbDevice.getIdElement().getValue());
                resourceReference.setType("Device");
                resourceReference.setIdentifier(new Identifier().setSystem(dbDevice.getIdentifierFirstRep().getSystem())
                        .setValue(dbDevice.getIdentifierFirstRep().getValue()));
                resourceReference.setDisplay(dbDevice.getDeviceNameFirstRep().getName());
            } else {
                resourceReference.setType("Device");
                resourceReference.setIdentifier(new Identifier().setSystem(device.getIdentifierFirstRep().getSystem())
                        .setValue(device.getIdentifierFirstRep().getValue()));
                if (device.getDeviceNameFirstRep() != null)
                    resourceReference.setDisplay(device.getDeviceNameFirstRep().getName());
            }
        } else if (resource instanceof Organization) {
            Organization organization = (Organization) resource;
            SearchParameterMap searchParams = new SearchParameterMap();
            searchParams.add("identifier", new TokenParam(organization.getIdentifierFirstRep().getSystem(),
                    organization.getIdentifierFirstRep().getValue()));

            List<Organization> matchedOrganizations = organizationDao.searchForResources(searchParams, requestDetails);

            if (!matchedOrganizations.isEmpty()) {
                Organization dbOrganization = matchedOrganizations.get(0);
                resourceReference.setReference(dbOrganization.getIdElement().getValue());
                resourceReference.setType("Organization");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(dbOrganization.getIdentifierFirstRep().getSystem())
                                .setValue(dbOrganization.getIdentifierFirstRep().getValue()));
                resourceReference.setDisplay(dbOrganization.getName());
            } else {
                resourceReference.setType("Organization");
                resourceReference
                        .setIdentifier(new Identifier().setSystem(organization.getIdentifierFirstRep().getSystem())
                                .setValue(organization.getIdentifierFirstRep().getValue()));
                if (organization.getName() != null)
                    resourceReference.setDisplay(organization.getName());
            }
        }

        return resourceReference;
    }

    public static String getValueString(QuestionnaireResponse qr, String linkId) {
        for (QuestionnaireResponse.QuestionnaireResponseItemComponent item : qr.getItem()) {
            if (item.getLinkId().equals(linkId) && !item.getAnswer().isEmpty()) {
                return item.getAnswerFirstRep().getValueStringType().getValue();
            }
        }
        return null; // Return null if not found
    }

    public static CodeableConcept getValueCodeableConcept(QuestionnaireResponse qr, String linkId) {
        for (QuestionnaireResponse.QuestionnaireResponseItemComponent item : qr.getItem()) {
            if (item.getLinkId().equals(linkId) && !item.getAnswer().isEmpty()) {
                return new CodeableConcept(item.getAnswerFirstRep().getValueCoding());
            }
        }
        return null; // Return null if not found
    }

}